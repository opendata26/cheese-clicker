#ifndef __EXCEPTION_HANDLER_H_
#define __EXCEPTION_HANDLER_H_

#ifdef __cplusplus
extern "C" {
#endif

void setup_os_exceptions(void);

#ifdef __cplusplus
}
#endif

#endif
