#Flappy Bird GX2#
A GX2 Flappy Bird port for the WiiU.  
Assets from Floppy Bird (HTML5 and the original Android game).  

#Usage#
Press A to begin the Game  
Press A to jump  
Press HOME to exit  
Avoid the pipes and the flor!  

#Building#
In order to build this application, you need the custom liboGC and portlibs modified/created by dimok. You can find them on the loadiine_gx2 repo (https://github.com/dimok789/loadiine_gx2/releases/tag/v0.2). Simply put the files in your devkit folder and run the Makefile. 

#Credits:#
**dimok** - WiiU librabries, dynamic_libs, examples, Homebrew Launcher  
**Maschell** - GX2_Example and coding help  
**vgmoose** - Coding help  
**pwsincd** - Icon  
**QuarkTheAwesome, dylon99** - Various help and testing  
